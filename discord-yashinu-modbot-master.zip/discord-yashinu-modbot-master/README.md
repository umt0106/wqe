## Proje kasıtlı olarak kullanacak kişilerin sorunları kendi başlarına çözmeleri için eksik ve hatalı paylaşılmıştır, zamanla eksikler ve hatalar düzeltilecektir.
## Panel komutundan sunucu bilgilerini ve ALYA.js adlı dosyadan emoji ID'lerini girmeyi unutmayın.

## Selam dostlarım, bir süre önce kullandığım sunucuya özel botlarımı açık kaynak olarak herkese açık bir şekilde paylaşmaya karar verdim. Kullanımıyla alakalı ve diğer şeylerle ilgili destek/yardım almak için aşağıya bırakacağım topluluk sunucumuzdan yardım alabilirsiniz.

# Yashinu & Alosha

 Projenin ücretli satılması veya başkası tarafından, başka bir ad ile dağıtılması kesinlikle yasaktır. Proje lisanslı bir projedir, bu tarz işlemlerde bulunanlar olur ise lisans aracılığı ile gerekli yasal yollara başvurulacaktır.
<p align="center">
  <a href="https://discord.gg/ZBmhQ2T"><img src="https://img.shields.io/badge/Serendia%20Squad%20-1d202b.svg?&style=for-the-badge&logo=discord&logoColor=white"></a>
  <a href="https://discord.com/users/460813657811582986"><img src="https://img.shields.io/badge/Yashinu%20-7289DA.svg?&style=for-the-badge&logo=discord&logoColor=white"></a>
</p>
